This is the Java Spatial Index library.

For examples of usage, please see https://github.com/aled/jsi-examples